$.numericSetStatic('date-now', 'now');
$.numericSetEn('date-minute', 'a minute ago', '* minutes ago');
$.numericSetEn('date-hour', 'a hour ago', '* hours ago');
$.numericSetEn('date-day', 'to day', '* days ago');
<?
if(isset($kernel)&&isset($_POST['type'])){
    
    switch($_POST['type']){
        case 'add':            
            
            break;
        case 'edit':            
            
            break;
        case 'delete':
            
            break;
        case 'db_add':
            
            break;
        case 'db_edit':
            
            break;
        case 'db_delete':
            
            break;
        case 'db_enabled':
            
            break;
        case 'db_default':
            
            break;
        case 'db_sort':
            
    }
}
?>
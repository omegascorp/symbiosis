$(window).scroll(function(){
    /*
    $('.admin-top').animate({
        'top': $(window).scrollTop()+'px'
    }, {'speed':500, 'queue': false});
    */
});
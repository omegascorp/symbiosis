<?
Data::clearFolder('temp/', 'important');
?>
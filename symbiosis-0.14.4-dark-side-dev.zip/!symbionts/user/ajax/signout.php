<?
if(isset($kernel)){
    $user->signout();
}
?>